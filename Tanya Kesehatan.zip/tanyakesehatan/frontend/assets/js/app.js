const API_BASE = 'http://localhost:4000/api';

// --- helper storage (simpan user di localStorage untuk demo) ---
function setCurrentUser(u){ localStorage.setItem('tk_user', JSON.stringify(u)); }
function getCurrentUser(){ return JSON.parse(localStorage.getItem('tk_user') || 'null'); }
function logout(){ localStorage.removeItem('tk_user'); location.href = 'index.html'; }

// --- login form handler ---
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      try {
        const r = await fetch(`${API_BASE}/login`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({username,password})
        });
        const data = await r.json();
        if (!r.ok) { document.getElementById('msg').innerText = data.error || 'Login failed'; return; }
        setCurrentUser(data.user);
        // redirect to dashboard
        window.location.href = 'dashboard.html';
      } catch(err){ document.getElementById('msg').innerText = 'Server error'; }
    });
  }

  // dashboard init
  const user = getCurrentUser();
  if (document.getElementById('welcome')) {
    if (!user) { window.location.href = 'login.html'; return; }
    document.getElementById('welcome').innerHTML = `<h3>Halo, ${user.name} (${user.role})</h3>`;
    document.getElementById('logoutBtn').addEventListener('click', logout);
    if (user.role === 'doctor') {
      document.getElementById('doctorControls').style.display = 'block';
    } else {
      document.getElementById('patientControls').style.display = 'block';
    }

    // add article
    const addArticleForm = document.getElementById('addArticleForm');
    if (addArticleForm) {
      addArticleForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('artTitle').value;
        const content = document.getElementById('artContent').value;
        const res = await fetch(`${API_BASE}/articles`, {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({title, content, authorId: user.id})
        });
        if (res.ok) {
          alert('Artikel ditambahkan');
          document.getElementById('artTitle').value = '';
          document.getElementById('artContent').value = '';
        } else {
          alert('Gagal menambah artikel');
        }
      });
    }

    // rename site (doctor)
    const renameSiteForm = document.getElementById('renameSiteForm');
    if (renameSiteForm) {
      renameSiteForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('siteName').value;
        if (!title) return alert('Masukkan nama situs');
        const res = await fetch(`${API_BASE}/site`, {
          method:'PUT', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({title})
        });
        if (res.ok) {
          alert('Nama situs disimpan');
          document.getElementById('siteTitle').innerText = title;
        } else alert('Gagal');
      });
    }
  }

  // articles page
  const articlesList = document.getElementById('articlesList');
  if (articlesList) {
    fetch(`${API_BASE}/articles`).then(r => r.json()).then(data => {
      if (!Array.isArray(data)) { articlesList.innerText = 'Tidak ada artikel'; return; }
      articlesList.innerHTML = data.map(a => `
        <div class="card mb-3">
          <div class="card-header">${a.title} <small class="float-end">${new Date(a.createdAt).toLocaleString()}</small></div>
          <div class="card-body">${a.content}</div>
        </div>
      `).join('');
    });
  }

  // doctors page
  const doctorsList = document.getElementById('doctorsList');
  if (doctorsList) {
    fetch(`${API_BASE}/doctors`).then(r=>r.json()).then(data => {
      if (!data.length) doctorsList.innerHTML = '<p>Tidak ada dokter</p>';
      doctorsList.innerHTML = data.map(d => `
        <div class="card mb-2">
          <div class="card-body">
            <h5>${d.name} <small class="text-muted">(${d.specialty})</small></h5>
            <p>${d.profile}</p>
          </div>
        </div>
      `).join('');
    });
  }

  // bookings page: load doctors into select and list bookings
  const doctorSelect = document.getElementById('doctorSelect');
  if (doctorSelect) {
    fetch(`${API_BASE}/doctors`).then(r=>r.json()).then(data=>{
      doctorSelect.innerHTML = data.map(d => `<option value="${d.id}">${d.name} — ${d.specialty}</option>`).join('');
    });
    // booking list
    const bookingList = document.getElementById('bookingList');
    async function loadBookings(){
      const res = await fetch(`${API_BASE}/bookings`);
      const b = await res.json();
      if (!b.length) bookingList.innerHTML = '<p>Belum ada booking</p>';
      else bookingList.innerHTML = b.map(x => {
        const dt = new Date(x.date).toLocaleString();
        return `<div class="card mb-2"><div class="card-body"><b>${dt}</b><div>${x.notes || ''}</div></div></div>`;
      }).join('');
    }
    loadBookings();

    const bookingForm = document.getElementById('bookingForm');
    bookingForm.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const docId = doctorSelect.value;
      const dt = document.getElementById('bookingDate').value;
      const notes = document.getElementById('bookingNotes').value;
      const user = getCurrentUser();
      // If not logged in, require name: here we require login
      if (!user) return alert('Silakan login terlebih dahulu');
      const iso = new Date(dt).toISOString();
      const res = await fetch(`${API_BASE}/bookings`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ patientId: user.id, doctorId: docId, date: iso, notes })
      });
      if (res.ok) {
        alert('Booking dibuat');
        bookingForm.reset();
        loadBookings();
      } else {
        const err = await res.json();
        alert(err.error || 'Gagal');
      }
    });
  }

  // site title show
  const siteTitleEl = document.getElementById('siteTitle');
  if (siteTitleEl) {
    fetch(`${API_BASE}/site`).then(r=>r.json()).then(s=>{
      siteTitleEl.innerText = s.title || 'Tanya Kesehatan';
    });
  }
});

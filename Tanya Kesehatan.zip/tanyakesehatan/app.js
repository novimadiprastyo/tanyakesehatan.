document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("currentUser"));

  const guestMenu = document.getElementById("guestMenu");
  const userMenu = document.getElementById("userMenu");
  const welcomeText = document.getElementById("welcomeText");
  const addArticleBtn = document.getElementById("addArticleBtn");

  // kalau bukan index.html, stop
  if (!guestMenu || !userMenu) return;

  if (user) {
    // user login
    guestMenu.classList.add("d-none");
    userMenu.classList.remove("d-none");

    welcomeText.innerText = `Halo, ${user.username}`;

    if (user.role === "doctor") {
      addArticleBtn.classList.remove("d-none");
    }

  } else {
    // belum login
    guestMenu.classList.remove("d-none");
    userMenu.classList.add("d-none");
  }
});

function logout() {
  localStorage.removeItem("currentUser");
  location.href = "index.html";
}

const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const { v4: uuidv4 } = require('uuid');
const path = require('path');

// DATA FILE DI ROOT PROJECT
const DATA_FILE = path.join(__dirname, 'data.json');

const app = express();
app.use(cors());
app.use(express.json());

async function readData() {
  const txt = await fs.readFile(DATA_FILE, 'utf8');
  return JSON.parse(txt);
}

async function writeData(data) {
  await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

/** REGISTER */
app.post('/api/register', async (req, res) => {
  const { username, password, name, role } = req.body;
  if (!username || !password || !role)
    return res.status(400).json({ error: 'Missing fields' });

  const data = await readData();
  if (data.users.find(u => u.username === username)) {
    return res.status(400).json({ error: 'Username exists' });
  }

  const user = { id: uuidv4(), username, password, role, name: name || username };
  data.users.push(user);
  await writeData(data);

  res.json({ success: true, user });
});

/** LOGIN */
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const data = await readData();
  const user = data.users.find(u => u.username === username && u.password === password);

  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  res.json({ success: true, user });
});

/** SITE INFO */
app.get('/api/site', async (req, res) => {
  const data = await readData();
  res.json(data.site || { title: "Tanya Kesehatan" });
});

app.put('/api/site', async (req, res) => {
  const { title } = req.body;
  const data = await readData();
  data.site = data.site || {};
  data.site.title = title;

  await writeData(data);
  res.json({ success: true, site: data.site });
});

/** ARTICLES */
app.get('/api/articles', async (req, res) => {
  const data = await readData();
  const sorted = (data.articles || [])
    .slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json(sorted);
});

app.post('/api/articles', async (req, res) => {
  const { title, content, authorId } = req.body;
  if (!title || !content || !authorId)
    return res.status(400).json({ error: "Missing fields" });

  const data = await readData();
  const article = {
    id: uuidv4(),
    title,
    content,
    authorId,
    createdAt: new Date().toISOString()
  };

  data.articles = data.articles || [];
  data.articles.push(article);
  await writeData(data);

  res.json({ success: true, article });
});

/** DOCTORS */
app.get('/api/doctors', async (req, res) => {
  const data = await readData();
  res.json(data.doctors || []);
});

/** BOOKINGS */
app.get('/api/bookings', async (req, res) => {
  const data = await readData();
  const { patientId, doctorId } = req.query;
  
  let list = data.bookings || [];

  if (patientId) list = list.filter(b => b.patientId === patientId);
  if (doctorId) list = list.filter(b => b.doctorId === doctorId);

  list = list.sort((a, b) => new Date(a.date) - new Date(b.date));

  res.json(list);
});

app.post('/api/bookings', async (req, res) => {
  const { patientId, doctorId, date, notes } = req.body;

  if (!patientId || !doctorId || !date)
    return res.status(400).json({ error: "Missing fields" });

  const data = await readData();
  const booking = {
    id: uuidv4(),
    patientId,
    doctorId,
    date,
    notes: notes || ""
  };

  data.bookings.push(booking);
  await writeData(data);

  res.json({ success: true, booking });
});

/* SERVE FRONTEND */
app.use(express.static(path.join(__dirname, 'frontend')));

// fallback untuk semua route lain
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

/** START SERVER */
const PORT = process.env.PORT || 4000;
app.listen(PORT, () =>
  console.log(`Server running at http://localhost:${PORT}`)
);
